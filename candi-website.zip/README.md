# Eksplorasi Candi Indonesia

Project website sederhana bertema candi Indonesia.

## Fitur
- Halaman Home
- Daftar Candi
- Desain sederhana menggunakan HTML & CSS

## Cara Menjalankan
Cukup buka file `index.html` di browser.
